(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


class DialogflowV1 {
    constructor(req) {
        this.platform = 'facebook';

        console.log(req);
        this.contexts = req.result.contexts;

        this.response = {
            messages: []
        };

        this.addTextMessage = this.addTextMessage.bind(this);
        this.removeFirstTextMessage = this.removeFirstTextMessage.bind(this);
        this.addQuickReplies = this.addQuickReplies.bind(this);
        this.getResponse = this.getResponse.bind(this);
    }

    // https://dialogflow.com/docs/reference/agent/message-objects
    addTextMessage(text) {
        this.response.messages.push({
            platform: this.platform,
            speech: text,
            type: 0
        });
    }
    removeFirstTextMessage() {
        this.response.messages.shift();
    }

    addCard(title, subtitle, imageUrl, buttons) {
        this.response.messages.push({
            buttons,
            imageUrl,
            platform: this.platform,
            subtitle,
            title,
            type: 1
        });
    }

    // https://dialogflow.com/docs/reference/agent/message-objects
    addQuickReplies(title, quickReplies) {
        this.response.messages.push({
            platform: this.platform,
            replies: quickReplies,
            title,
            type: 2
        });
    }

    getResponse() {
        return this.response;
    }
}

const lenders = [{
    name: 'Cetelem',
    minAmount: 3000,
    maxAmount: 50000,
    url: '[Cetelem](https://www.cetelem.es/)'
}, {
    name: 'Cofidis',
    minAmount: 4000,
    maxAmount: 50000,
    url: '[Confidis](https://www.cofidis.es/)'
}, {
    name: 'Creditea',
    minAmount: 100,
    maxAmount: 3000,
    url: '[Creditea](https://creditea.com/)'
}, {
    name: 'Quebueno',
    minAmount: 50,
    maxAmount: 300,
    url: '[Quebueno](https://www.quebueno.es/)'
}, {
    name: 'Solcredito',
    minAmount: 100,
    maxAmount: 1000,
    url: '[Solcredito](https://www.solcredito.es/)'
}, {
    name: 'Vivus',
    minAmount: 50,
    maxAmount: 300,
    url: '[Vivus](https://www.vivus.es/)'
}, {
    name: 'Wonga',
    minAmount: 50,
    maxAmount: 300,
    url: '[Wonga](https://www.wonga.es/)'
}, {
    name: 'Younited',
    minAmount: 1000,
    maxAmount: 40000,
    url: '[Younited](https://es.younited-credit.com/)'
}];

function aldaFinancingPrestamo(agent) {
    const amount = agent.contexts[0].parameters.amount;
    let foundLender = false;
    let totalMinAmount;
    let totalMaxAmount;
    agent.addTextMessage(`Perfecto, a continuación te muestro los mejores préstamos que ofrecen ${amount}€`);

    for (const lender of lenders) {
        const { name, minAmount, maxAmount, url } = lender;
        if (minAmount <= amount && amount <= maxAmount) {
            foundLender = true;
            agent.addCard(name, 'subtitle', 'https://www.w3schools.com/howto/img_forest.jpg', [{
                postback: 'url',
                text: url
            }]);
        }
        if (typeof totalMinAmount === 'undefined' || totalMinAmount > minAmount) {
            totalMinAmount = minAmount;
        }
        if (typeof totalMaxAmount === 'undefined' || totalMaxAmount < maxAmount) {
            totalMaxAmount = maxAmount;
        }
    }

    if (!foundLender) {
        agent.removeFirstTextMessage();
        agent.addTextMessage(`Por ${amount} € no he encontrado un prestamista 😔`);
        if (amount < totalMinAmount) {
            agent.addQuickReplies(`Tendrias que pedir por lo minimum:`, [`${totalMinAmount}€`]);
        }
        if (amount > totalMaxAmount) {
            agent.addQuickReplies(`Tendrias que pedir menos que:`, [`${totalMaxAmount}€`]);
        }
    }
}

const index = (event, context, callback) => {
    // console.log(JSON.stringify(JSON.parse(event.body), null, 4));

    const body = process.env.IS_LOCAL ? event.body : JSON.parse(event.body);

    console.log(body);
    console.log(JSON.stringify(body, null, 4));

    const agent = new DialogflowV1(body);
    // agent.addTextMessage('lol');
    // agent.addTextMessage('non');
    // agent.addQuickReplies('title', ['lol', 'ok', 'nice']);
    // agent.addCard('title', 'subtitle', 'https://www.w3schools.com/howto/img_forest.jpg', [{
    //     postback: 'lol',
    //     text: 'ok'
    // }]);

    aldaFinancingPrestamo(agent);

    const response = {
        statusCode: 200,
        body: JSON.stringify(agent.getResponse())
    };
    callback(null, response);
};
/* harmony export (immutable) */ __webpack_exports__["index"] = index;


/***/ })
/******/ ])));